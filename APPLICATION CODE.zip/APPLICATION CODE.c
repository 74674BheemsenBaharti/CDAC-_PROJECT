#include<stdio.h>
#include<stdint.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<sys/ioctl.h>
#include<linux/i2c-dev.h>
#include<stdlib.h>

#define MPU6050_ADDR        0x68       // MPU6050 I2C address
#define MPU6050_PWR_MGMT    0x6B       //MPU6050 power management register 

//mpu6050 address to get accelerometer values
#define ACCEL_XOUT_H        0x3B
#define ACCEL_XOUT_L        0x3C
#define ACCEL_YOUT_H        0x3D
#define ACCEL_YOUT_L        0x3E
#define ACCEL_ZOUT_H        0x3F
#define ACCEL_ZOUT_L        0x40

//mpu6050 address to get gyro values
#define GYRO_XOUT_H         0x43
#define GYRO_XOUT_L         0x44
#define GYRO_YOUT_H         0x45
#define GYRO_YOUT_L         0x46
#define GYRO_ZOUT_H         0x47
#define GYRO_ZOUT_L         0x48

//sensitivities offered by the accelerometer-
#define ACC_FS_SENSITIVITY_0 16384
#define ACC_FS_SENSITIVITY_1 8192
#define ACC_FS_SENSITIVITY_2 4096
#define ACC_FS_SENSITIVITY_3 2048

//sensitivities offered by the gyroscope-
#define GYR_FS_SENSITIVITY_0 131
#define GYR_FS_SENSITIVITY_1 65.5
#define GYR_FS_SENSITIVITY_2 32.8
#define GYR_FS_SENSITIVITY_3 16.4


int file;

int MPU6050_write(uint8_t add,uint8_t data){
    char buf[2];
    buf[0]=add;
    buf[1]=data;
    if(write(file,buf,sizeof(buf))<0){
        printf("error in the write\n");
        return -1;
    }

    return 0;
}

void MPU6050_init()
{
    //to open the node which is associated with the mpu6050 to communicate
    file=open("/dev/i2c-2", O_RDWR);
    if(file<0){
        printf("error in opening the file\n");
        return;
    }

    //to set mpu6050 as i2c slave 
    if (ioctl(file, I2C_SLAVE, MPU6050_ADDR) < 0){
        printf("error in ioctl setting slave\n");
        return;
    }

    MPU6050_write(MPU6050_PWR_MGMT,0x00);

}

void MPU6050_read_accel(uint8_t baseadd, uint16_t *accdata){
    
    char buf[2];
    buf[0]=baseadd;
    if(write(file,buf,1)<0){
        printf("error in the write\n");
    }
    
    uint8_t rawdata[6];
    if(read(file,rawdata,6)<0){
        printf("error in reading the raw data\n");
        return ;
    }

    accdata[0]= (rawdata[0]<<8 | rawdata[1]);
    accdata[1]= (rawdata[2]<<8 | rawdata[3]);
    accdata[2]= (rawdata[4]<<8 | rawdata[5]);
}

void MPU6050_read_gyro(uint8_t baseadd, uint16_t *gyrodata){
    
    char buf[2];
    buf[0]=baseadd;
    if(write(file,buf,1)<0){
        printf("error in the write\n");
    }
    
    uint8_t rawdata[6];
    if(read(file,rawdata,6)<0){
        printf("error in reading the raw data\n");
        return ;
    }

    gyrodata[0]= (rawdata[0]<<8 | rawdata[1]);
    gyrodata[1]= (rawdata[2]<<8 | rawdata[3]);
    gyrodata[2]= (rawdata[4]<<8 | rawdata[5]);
}

int main(){
    //to store the of accelerometer and gyro 
    uint16_t accdata[3], gyrodata[3];
    //to read register values after setting sensitivity
    double accel_x,accel_y,accel_z,gyro_x,gyro_y,gyro_z;

    MPU6050_init();

   while (1)
   {
     MPU6050_read_accel(ACCEL_XOUT_H, accdata);
     MPU6050_read_gyro(GYRO_XOUT_H, gyrodata);


     //converting raw values to g values for accelerometer

     accel_x=(double) accdata[0]/ACC_FS_SENSITIVITY_0;
     accel_y=(double) accdata[1]/ACC_FS_SENSITIVITY_0;
     accel_z=(double) accdata[2]/ACC_FS_SENSITIVITY_0;

     //converting raw values of gryoscope to %s values

     gyro_x=(double)gyrodata[0]/GYR_FS_SENSITIVITY_0;
     gyro_y=(double)gyrodata[1]/GYR_FS_SENSITIVITY_0;
     gyro_z=(double)gyrodata[2]/GYR_FS_SENSITIVITY_0;


    //printing raw values

     printf("Accelerometer: X=%d, Y=%d, Z=%d\n", accdata[0], accdata[1], accdata[2]);
     printf("Gyroscope: X=%d, Y=%d, Z=%d\n", gyrodata[0], gyrodata[1], gyrodata[2]);

     //printing gyro and accel values after adjusting sensitivity

    printf("------------------after sensitivity-------------------------\n");
    printf("Accelerometer in g: X=%.3f, Y=%.3f, Z=%.3f\n", accel_x, accel_y, accel_z);
     printf("Gyroscope in deg/sec: X=%.3f, Y=%.3f, Z=%.3f\n", gyro_x, gyro_y, gyro_z);


     usleep(500000); //sleep for 0.5 sec
   }
   

    return 0;
}